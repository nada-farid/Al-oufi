
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.client.title')); ?>

    </div>
    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.clients.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <div class="row">
                <div class="col-md-4">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($client->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.client_name')); ?>

                        </th>
                        <td>
                            <?php echo e($client->client_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.tel_1')); ?>

                        </th>
                        <td>
                            <?php echo e($client->tel_1); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.tel_2')); ?>

                        </th>
                        <td>
                            <?php echo e($client->tel_2); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.tax_number')); ?>

                        </th>
                        <td>
                            <?php echo e($client->tax_number); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.short_name')); ?>

                        </th>
                        <td>
                            <?php echo e($client->short_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($client->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.address')); ?>

                        </th>
                        <td>
                            <?php echo e($client->address); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.fax')); ?>

                        </th>
                        <td>
                            <?php echo e($client->fax); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.contact_person')); ?>

                        </th>
                        <td>
                            <?php echo e($client->contact_person); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.contact_person_2')); ?>

                        </th>
                        <td>
                            <?php echo e($client->contact_person_2); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.bank_name')); ?>

                        </th>
                        <td>
                            <?php echo e($client->bank_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.home_tel')); ?>

                        </th>
                        <td>
                            <?php echo e($client->home_tel); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.iban')); ?>

                        </th>
                        <td>
                            <?php echo e($client->iban); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.mobile_number_1')); ?>

                        </th>
                        <td>
                            <?php echo e($client->mobile_number_1); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.mobile_number_2')); ?>

                        </th>
                        <td>
                            <?php echo e($client->mobile_number_2); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.remarks')); ?>

                        </th>
                        <td>
                            <?php echo e($client->remarks); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.from')); ?>

                        </th>
                        <td>
                            <?php echo e($client->from); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.client.fields.to')); ?>

                        </th>
                        <td>
                            <?php echo e($client->to); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.clients.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
</div>
<div class="col-md-8">   
<div class="card">
    <div class="card-header">
        <strong style="color: #00008B;"> Client Fees</strong>
    </div>
    <div class="card-body">
<table>
    <tr>
        <th>
        </th>
        <th>
            Clearance Fee
        </th>
        <th>
            Transportaion Fee
        </th>
        <th>
            Loading Fee
        </th>
    </tr>
    <?php $__currentLoopData = $client_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ClientFee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>      
            <td><?php echo e(App\Models\ClientFee::findOrfail($ClientFee->client_fee_id)->type); ?></td>
          
            <td><input value="<?php echo e($ClientFee->clearance_fee ?? null); ?>"  data-id="<?php echo e($ClientFee->client_fee_id); ?>" disabled></td> 
            <td><input value="<?php echo e($ClientFee->transportaion ?? null); ?>"  data-id="<?php echo e($ClientFee->client_fee_id); ?>" disabled></td>       
            <td><input value="<?php echo e($ClientFee->loading_fee ?? null); ?>"  data-id="<?php echo e($ClientFee->client_fee_id); ?>" disabled></td>             
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    </div>
</div>
</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/clients/show.blade.php ENDPATH**/ ?>