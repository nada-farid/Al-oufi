
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.invoice.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.invoices.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.awb')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->awb->awb_no ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.invoice_date')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->invoice_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.client')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->client->client_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.amount')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->amount); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.vat')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->vat); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.total')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->total); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.remarks')); ?>

                        </th>
                        <td>
                            <?php echo e($invoice->remarks); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.invoices.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/invoices/show.blade.php ENDPATH**/ ?>