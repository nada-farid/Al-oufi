<table>
    <tr>
        <th>
        </th>
        <th>
            Clearance Fee
        </th>
        <th>
            Transportaion Fee
        </th>
        <th>
            Loading Fee
        </th>
    </tr>
    <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ClientFee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>      
            <td><?php echo e($ClientFee->type); ?></td>
          
            <td><input value="<?php echo e($ClientFee->clearance_fee ?? null); ?>"  data-id="<?php echo e($ClientFee->id); ?>" name="fees[<?php echo e($ClientFee->id); ?>][]" type="number" class="ingredient-amount form-control"></td> 
            <td><input value="<?php echo e($ClientFee->transportaion ?? null); ?>"  data-id="<?php echo e($ClientFee->id); ?>" name="fees[<?php echo e($ClientFee->id); ?>][]" type="number" class="ingredient-amount form-control"></td>       
            <td><input value="<?php echo e($ClientFee->loading_fee ?? null); ?>"  data-id="<?php echo e($ClientFee->id); ?>" name="fees[<?php echo e($ClientFee->id); ?>][]" type="number" class="ingredient-amount form-control"></td>             
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/clients/partial/fees.blade.php ENDPATH**/ ?>