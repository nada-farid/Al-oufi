
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.awb.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.awbs.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.awb_no')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->awb_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.no_of_pcs')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->no_of_pcs); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.goods_type')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->goods_type); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.decleration_no')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->decleration_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.goods_weight')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->goods_weight); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.declaration_date')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->declaration_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.declaration_file')); ?>

                        </th>
                        <td>
                            <?php if($awb->declaration_file): ?>
                                <a href="<?php echo e($awb->declaration_file->getUrl()); ?>" target="_blank">
                                    <?php echo e(trans('global.view_file')); ?>

                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.delivery_no')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->delivery_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.delivery_date')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->delivery_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.delivery_amount')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->delivery_amount); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.goods_date')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->goods_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.customer_fees')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->customer_fees); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.receipt_no')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->receipt_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.receipt_date')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->receipt_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.awb.fields.remarks')); ?>

                        </th>
                        <td>
                            <?php echo e($awb->remarks); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.awbs.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/awbs/show.blade.php ENDPATH**/ ?>