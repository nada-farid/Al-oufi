
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.notification.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.notifications.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($notification->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.awb_no')); ?>

                        </th>
                        <td>
                            <?php echo e($notification->awb_no); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.client')); ?>

                        </th>
                        <td>
                            <?php echo e($notification->client->client_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.awb_date')); ?>

                        </th>
                        <td>
                            <?php echo e($notification->awb_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.awb_file')); ?>

                        </th>
                        <td>
                            <?php if($notification->awb_file): ?>
                                <a href="<?php echo e($notification->awb_file->getUrl()); ?>" target="_blank">
                                    <?php echo e(trans('global.view_file')); ?>

                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.remarks')); ?>

                        </th>
                        <td>
                            <?php echo e($notification->remarks); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.notification.fields.appearance')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Notification::APPEARANCE_SELECT[$notification->appearance] ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.notifications.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/notifications/show.blade.php ENDPATH**/ ?>