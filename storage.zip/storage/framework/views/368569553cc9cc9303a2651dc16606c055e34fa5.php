
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.client.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.clients.update", [$client->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header">
                    <strong style="color: #00008B;"> Client Information</strong>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="form-group col-md-3">
                            <label
                                for="client_no"><?php echo e(trans('cruds.client.fields.client_no')); ?></label>
                            <input class="form-control <?php echo e($errors->has('client_no') ? 'is-invalid' : ''); ?>" type="text"
                                name="client_no" id="client_no"  disabled    value="<?php echo e($client->id); ?>" />
                        </div>
                        <div class="form-group col-md-6">
                            <label class="required"
                                for="client_name"><?php echo e(trans('cruds.client.fields.client_name')); ?></label>
                            <input class="form-control <?php echo e($errors->has('client_name') ? 'is-invalid' : ''); ?>"
                                type="text" name="client_name" id="client_name" value="<?php echo e(old('client_name', $client->client_name)); ?>"
                                required >
                            <?php if($errors->has('client_name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('client_name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.client_name_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="required"
                                for="tel_1"><?php echo e(trans('cruds.client.fields.tel_1')); ?></label>
                            <input class="form-control <?php echo e($errors->has('tel_1') ? 'is-invalid' : ''); ?>" type="text"
                                name="tel_1" id="tel_1"  required value="<?php echo e(old('tel_1', $client->tel_1)); ?>">
                            <?php if($errors->has('tel_1')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('tel_1')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.tel_1_helper')); ?></span>
                        </div>

                        <div class="form-group col-md-3">
                            <label class="required"
                                for="tax_number"><?php echo e(trans('cruds.client.fields.tax_number')); ?></label>
                            <input class="form-control <?php echo e($errors->has('tax_number') ? 'is-invalid' : ''); ?>"
                                type="text" name="tax_number" id="tax_number" value="<?php echo e(old('tax_number', $client->tax_number)); ?>" 
                                required>
                            <?php if($errors->has('tax_number')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('tax_number')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.tax_number_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="required"
                                for="short_name"><?php echo e(trans('cruds.client.fields.short_name')); ?></label>
                            <input class="form-control <?php echo e($errors->has('short_name') ? 'is-invalid' : ''); ?>"
                                type="text" name="short_name" id="short_name" value="<?php echo e(old('short_name',$client->short_name)); ?>"
                                required>
                            <?php if($errors->has('short_name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('short_name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.short_name_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="tel_2"><?php echo e(trans('cruds.client.fields.tel_2')); ?></label>
                            <input class="form-control <?php echo e($errors->has('tel_2') ? 'is-invalid' : ''); ?>" type="text"
                                name="tel_2" id="tel_2" value="<?php echo e(old('tel_2', $client->tel_2)); ?>">
                            <?php if($errors->has('tel_2')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('tel_2')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.tel_2_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="required"
                                for="email"><?php echo e(trans('cruds.client.fields.email')); ?></label>
                            <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email"
                                name="email" id="email" value="<?php echo e(old('email',$client->email)); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.email_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="required"
                                for="address"><?php echo e(trans('cruds.client.fields.address')); ?></label>
                            <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text"
                                name="address" id="address" value="<?php echo e(old('address', $client->address)); ?>" required>
                            <?php if($errors->has('address')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('address')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.address_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="fax"><?php echo e(trans('cruds.client.fields.fax')); ?></label>
                            <input class="form-control <?php echo e($errors->has('fax') ? 'is-invalid' : ''); ?>" type="text"
                                name="fax" id="fax" value="<?php echo e(old('fax', $client->fax)); ?>">
                            <?php if($errors->has('fax')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('fax')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.fax_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="required"
                                for="contact_person"><?php echo e(trans('cruds.client.fields.contact_person')); ?></label>
                            <input class="form-control <?php echo e($errors->has('contact_person') ? 'is-invalid' : ''); ?>"
                                type="text" name="contact_person" id="contact_person"
                                value="<?php echo e(old('contact_person', $client->contact_person)); ?>" required>
                            <?php if($errors->has('contact_person')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('contact_person')); ?>

                                </div>
                            <?php endif; ?>
                            <span
                                class="help-block"><?php echo e(trans('cruds.client.fields.contact_person_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="contact_person_2"><?php echo e(trans('cruds.client.fields.contact_person_2')); ?></label>
                            <input class="form-control <?php echo e($errors->has('contact_person_2') ? 'is-invalid' : ''); ?>"
                                type="text" name="contact_person_2" id="contact_person_2"
                                value="<?php echo e(old('contact_person_2', $client->contact_person_2)); ?>">
                            <?php if($errors->has('contact_person_2')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('contact_person_2')); ?>

                                </div>
                            <?php endif; ?>
                            <span
                                class="help-block"><?php echo e(trans('cruds.client.fields.contact_person_2_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="bank_name"><?php echo e(trans('cruds.client.fields.bank_name')); ?></label>
                            <input class="form-control <?php echo e($errors->has('bank_name') ? 'is-invalid' : ''); ?>"
                                type="text" name="bank_name" id="bank_name" value="<?php echo e(old('bank_name',$client->bank_name)); ?>">
                            <?php if($errors->has('bank_name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('bank_name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.bank_name_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="home_tel"><?php echo e(trans('cruds.client.fields.home_tel')); ?></label>
                            <input class="form-control <?php echo e($errors->has('home_tel') ? 'is-invalid' : ''); ?>"
                                type="text" name="home_tel" id="home_tel" value="<?php echo e(old('home_tel', $client->home_tel)); ?>">
                            <?php if($errors->has('home_tel')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('home_tel')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.home_tel_helper')); ?></span>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="iban"><?php echo e(trans('cruds.client.fields.iban')); ?></label>
                            <input class="form-control <?php echo e($errors->has('iban') ? 'is-invalid' : ''); ?>" type="text"
                                name="iban" id="iban" value="<?php echo e(old('iban',$client->iban)); ?>">
                            <?php if($errors->has('iban')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('iban')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.client.fields.iban_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="required"
                                for="mobile_number_1"><?php echo e(trans('cruds.client.fields.mobile_number_1')); ?></label>
                            <input class="form-control <?php echo e($errors->has('mobile_number_1') ? 'is-invalid' : ''); ?>"
                                type="text" name="mobile_number_1" id="mobile_number_1"
                                value="<?php echo e(old('mobile_number_1',$client->mobile_number_1)); ?>" required>
                            <?php if($errors->has('mobile_number_1')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('mobile_number_1')); ?>

                                </div>
                            <?php endif; ?>
                            <span
                                class="help-block"><?php echo e(trans('cruds.client.fields.mobile_number_1_helper')); ?></span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="mobile_number_2"><?php echo e(trans('cruds.client.fields.mobile_number_2')); ?></label>
                            <input class="form-control <?php echo e($errors->has('mobile_number_2') ? 'is-invalid' : ''); ?>"
                                type="text" name="mobile_number_2" id="mobile_number_2"
                                value="<?php echo e(old('mobile_number_2',$client->mobile_number_2)); ?>">
                            <?php if($errors->has('mobile_number_2')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('mobile_number_2')); ?>

                                </div>
                            <?php endif; ?>
                            <span
                                class="help-block"><?php echo e(trans('cruds.client.fields.mobile_number_2_helper')); ?></span>
                        </div>
                    </div>
                    <div class="form-group ">
                        <label for="remarks"><?php echo e(trans('cruds.client.fields.remarks')); ?></label>
                        <input class="form-control <?php echo e($errors->has('remarks') ? 'is-invalid' : ''); ?>" name="remarks"
                            id="remarks" value="<?php echo e(old('remarks',$client->remarks)); ?>">
                        <?php if($errors->has('remarks')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('remarks')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.client.fields.remarks_helper')); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <strong style="color: #00008B;"> Client fees</strong>
                        </div>
                        <div class="card-body">
                            <?php echo $__env->make('admin.clients.partial.fees_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <strong style="color: #00008B;"> Statement Of Account</strong>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label class="required"
                                    for="from"><?php echo e(trans('cruds.client.fields.from')); ?></label>
                                <input class="form-control date <?php echo e($errors->has('from') ? 'is-invalid' : ''); ?>"
                                    type="text" name="from" id="from" value="<?php echo e(old('from',$client->from)); ?>" required>
                                <?php if($errors->has('from')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('from')); ?>

                                    </div>
                                <?php endif; ?>
                                <span class="help-block"><?php echo e(trans('cruds.client.fields.from_helper')); ?></span>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="required" for="to"><?php echo e(trans('cruds.client.fields.to')); ?></label>
                                <input class="form-control date <?php echo e($errors->has('to') ? 'is-invalid' : ''); ?>"
                                    type="text" name="to" id="to" value="<?php echo e(old('to',$client->to)); ?>" required>
                                <?php if($errors->has('to')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('to')); ?>

                                    </div>
                                <?php endif; ?>
                                <span class="help-block"><?php echo e(trans('cruds.client.fields.to_helper')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" id="save_client" >
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/clients/edit.blade.php ENDPATH**/ ?>