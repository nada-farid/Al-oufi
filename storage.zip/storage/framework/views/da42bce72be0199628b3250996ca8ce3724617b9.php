<table>
    <tr>
        <th>
        </th>
        <th>
            Clearance Fee
        </th>
        <th>
            Transportaion Fee
        </th>
        <th>
            Loading Fee
        </th>
    </tr>
    <?php $__currentLoopData = $client_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ClientFee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>      
            <td><?php echo e(App\Models\ClientFee::findOrfail($ClientFee->client_fee_id)->type); ?></td>
          
            <td><input value="<?php echo e($ClientFee->clearance_fee ?? null); ?>"  data-id="<?php echo e($ClientFee->client_fee_id); ?>" name="fees[<?php echo e($ClientFee->client_fee_id); ?>][]" type="number" class="ingredient-amount form-control"></td> 
            <td><input value="<?php echo e($ClientFee->transportaion ?? null); ?>"  data-id="<?php echo e($ClientFee->client_fee_id); ?>" name="fees[<?php echo e($ClientFee->client_fee_id); ?>][]" type="number" class="ingredient-amount form-control"></td>       
            <td><input value="<?php echo e($ClientFee->loading_fee ?? null); ?>"  data-id="<?php echo e($ClientFee->client_fee_id); ?>" name="fees[<?php echo e($ClientFee->client_fee_id); ?>][]" type="number" class="ingredient-amount form-control"></td>             
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/clients/partial/fees_edit.blade.php ENDPATH**/ ?>