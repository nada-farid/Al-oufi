
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.notification.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.notifications.update", [$notification->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-md-4">
                <label class="required" for="awb_no"><?php echo e(trans('cruds.notification.fields.awb_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('awb_no') ? 'is-invalid' : ''); ?>" type="text" name="awb_no" id="awb_no" value="<?php echo e(old('awb_no', $notification->awb_no)); ?>" required>
                <?php if($errors->has('awb_no')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('awb_no')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.notification.fields.awb_no_helper')); ?></span>
            </div>
            <div class="form-group col-md-4">
                <label class="required" for="client_id"><?php echo e(trans('cruds.notification.fields.client')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="client_id" id="client_id" required>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('client_id') ? old('client_id') : $notification->client->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('client')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('client')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.notification.fields.client_helper')); ?></span>
            </div>
            <div class="form-group col-md-4">
                <label class="required" for="awb_date"><?php echo e(trans('cruds.notification.fields.awb_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('awb_date') ? 'is-invalid' : ''); ?>" type="text" name="awb_date" id="awb_date" value="<?php echo e(old('awb_date', $notification->awb_date)); ?>" required>
                <?php if($errors->has('awb_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('awb_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.notification.fields.awb_date_helper')); ?></span>
            </div>
            <div class="form-group col-md-4">
                <label for="awb_file"><?php echo e(trans('cruds.notification.fields.awb_file')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('awb_file') ? 'is-invalid' : ''); ?>" id="awb_file-dropzone">
                </div>
                <?php if($errors->has('awb_file')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('awb_file')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.notification.fields.awb_file_helper')); ?></span>
            </div>
            <div class="form-group col-md-4">
                <label for="remarks"><?php echo e(trans('cruds.notification.fields.remarks')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('remarks') ? 'is-invalid' : ''); ?>" name="remarks" id="remarks"><?php echo e(old('remarks', $notification->remarks)); ?></textarea>
                <?php if($errors->has('remarks')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('remarks')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.notification.fields.remarks_helper')); ?></span>
            </div>
            <div class="form-group col-md-4">
                <label class="required"><?php echo e(trans('cruds.notification.fields.appearance')); ?></label>
                <select class="form-control <?php echo e($errors->has('appearance') ? 'is-invalid' : ''); ?>" name="appearance" id="appearance" required>
                    <option value disabled <?php echo e(old('appearance', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Notification::APPEARANCE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('appearance', $notification->appearance) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('appearance')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('appearance')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.notification.fields.appearance_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.awbFileDropzone = {
    url: '<?php echo e(route('admin.notifications.storeMedia')); ?>',
    maxFilesize: 40, // MB
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 40
    },
    success: function (file, response) {
      $('form').find('input[name="awb_file"]').remove()
      $('form').append('<input type="hidden" name="awb_file" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="awb_file"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($notification) && $notification->awb_file): ?>
      var file = <?php echo json_encode($notification->awb_file); ?>

          this.options.addedfile.call(this, file)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="awb_file" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/notifications/edit.blade.php ENDPATH**/ ?>