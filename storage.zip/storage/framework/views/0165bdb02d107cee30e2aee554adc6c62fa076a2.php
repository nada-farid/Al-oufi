
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Invoice</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>

    <div class="row">
        <?php if( Config::get('app.locale') == 'en'): ?>
    <div class="card col-md-6">
        <div class="card-header">
        </div>
        <div class="card-body">
    <h4 class="center">Invoice Dateils</h4>
    <p>Client Name:<?php echo e($invoice->client->client_name); ?></p>
    <p>Tax Number:<?php echo e($invoice->client->tax_number); ?></p>
    <p>Invoice Number:<?php echo e($invoice->id); ?></p>
    <p>Invoice Date:<?php echo e($invoice->invoice_date); ?></p>
    <p>Invoice Amount Before Tax:<?php echo e($invoice->amount); ?></p>
    <p>Invoice VAT(15%):<?php echo e($invoice->vat); ?></p>
    <p>Invoice Total :<?php echo e($invoice->total); ?></p>
        </div>
    </div>
    <?php elseif( Config::get('app.locale') == 'ar' ): ?>
    <div class="card  col-md-4">
        <div class="card-header">
       
        </div>
        <div class="card-body">
    <h4> تفاصيل الفاتورة</h4>
    <p> اسم الشركة:<?php echo e($invoice->client->client_name); ?></p>
    <p>الرقم الضريبي:<?php echo e($invoice->client->tax_number); ?></p>
    <p>  رقم الفاتوره:<?php echo e($invoice->id); ?></p>
    <p> تاريخ اصدار الفاتوره<?php echo e($invoice->invoice_date); ?></p>
    <p>قيمة الفاتورة قبل الضريبه   :<?php echo e($invoice->amount); ?></p>
    <p>الضريبه (15%):<?php echo e($invoice->vat); ?></p>
    <p> قيمة الفاتورة بعد الضريبه :<?php echo e($invoice->total); ?></p>
        </div>
    </div>
    </div>
    <?php endif; ?>
</body>


<?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/invoices/QR.blade.php ENDPATH**/ ?>