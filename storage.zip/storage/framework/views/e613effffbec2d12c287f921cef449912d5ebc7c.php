
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.invoice.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Invoice">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.awb')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.invoice_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.client')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.vat')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.total')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.invoice.fields.remarks')); ?>

                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($invoice->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($invoice->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->awb->awb_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->invoice_date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->client->client_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->vat ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->total ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($invoice->remarks ?? ''); ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
        <div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.invoices.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 25,
  });
  let table = $('.datatable-Invoice:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Alliance\work\Al-oufi\Al-oufi\resources\views/admin/invoices/report.blade.php ENDPATH**/ ?>